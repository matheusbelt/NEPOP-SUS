<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Vpop
 */
?>
	<?php $footer = get_page_by_title('Home'); ?>
		<footer class="container-fluid bgblue" id="footer">
			<div class="container">
				<section class="col-md-3 col-md-offset-1">
					<img src="<?php echo bloginfo('template_directory'); ?>/img/nepops-footer.png" alt="">
				</section>
				<section class="col-md-3 col-md-offset-1">
					<nav class="footer-nav">
						<?php if(have_rows('menu_de_rodape', $footer)): while(have_rows('menu_de_rodape', $footer)) : the_row(); ?>
							<a href="<?php_the_sub_field('link', $footer); ?>"><?php the_sub_field('projeto_externo', $footer); ?> <br></a>
						<?php endwhile; else: endif; ?>
					</nav>
				</section>
				<section class="col-md-3">
					<nav class="footer-nav">
						<?php
							$args = array(
							'menu' => 'Rodapé',
							'theme_location' => 'footer-menu',
							'container' => false
							);
							wp_nav_menu( $args );
						?> 
					</nav>
				</section>
			</div>
		</footer>
<?php wp_footer(); ?>
</body>
</html>
