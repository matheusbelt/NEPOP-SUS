<h1 class="titulo-apresent verdana letrazul titulo-sidebar"><?php the_title(); ?></h1>
<ul>
	<a href="##" onClick="history.go(-1); return false;"><li><- Voltar</li></a>
</ul>